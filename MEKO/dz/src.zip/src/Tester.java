import java.util.Arrays;

public class Tester {
    public static void main(String[] args) {
        double[] params = RandomParams.getParams();
        System.out.println(Arrays.toString(params));
    }
}
