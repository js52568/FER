package dz1;

public interface IUnaryFunction {
    double valueAt(double x);
}
