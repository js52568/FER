package dz1;

public interface IFuzzySet {

    public IDomain getDomain();

    public double getValueAt(DomainElement de);
}
