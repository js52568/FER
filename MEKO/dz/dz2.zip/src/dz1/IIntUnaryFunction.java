package dz1;

public interface IIntUnaryFunction {
    public double valueAt(int x);
}
