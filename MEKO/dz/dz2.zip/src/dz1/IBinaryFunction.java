package dz1;

public interface IBinaryFunction {
    double valueAt(double x,double y);
}
