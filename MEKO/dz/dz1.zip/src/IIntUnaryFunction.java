public interface IIntUnaryFunction {
    public double valueAt(int x);
}
