public interface IBinaryFunction {
    double valueAt(double x,double y);
}
