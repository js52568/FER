public interface IUnaryFunction {
    double valueAt(double x);
}
